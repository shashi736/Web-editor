import { Component } from '@angular/core';

@Component({
  selector: 'app-web-editor',
  standalone: true,
  imports: [],
  templateUrl: './web-editor.component.html',
  styleUrl: './web-editor.component.css'
})
export class WebEditorComponent {

}
